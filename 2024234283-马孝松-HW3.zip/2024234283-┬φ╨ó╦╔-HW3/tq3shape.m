function [psi, dpsids, dpsidt] = tq3shape(s, t)
%TQSHAPE_CUBIC evaluates cubic shape functions for 10-node triangle
    one = 1.0e0; zero = 0.0e0;
    xi(1) = one - s - t;  % L1
    xi(2) = s;            % L2
    xi(3) = t;            % L3
    
    dxids(1) = -one;
    dxids(2) = one;
    dxids(3) = zero;
    dxidt(1) = -one;
    dxidt(2) = zero;
    dxidt(3) = one;

    % 顶点节点的形函数
    psi(1) = 0.5*xi(1)*(3*xi(1)-1)*(3*xi(1)-2);    % 节点1
    psi(2) = 0.5*xi(2)*(3*xi(2)-1)*(3*xi(2)-2);    % 节点2
    psi(3) = 0.5*xi(3)*(3*xi(3)-1)*(3*xi(3)-2);    % 节点3

    % 边上节点的形函数
    psi(4) = (9/2)*xi(1)*xi(2)*(3*xi(1)-1);        % 边12上第一个节点
    psi(5) = (9/2)*xi(2)*xi(1)*(3*xi(2)-1);        % 边12上第二个节点

    psi(6) = (9/2)*xi(2)*xi(3)*(3*xi(2)-1);        % 边23上第一个节点
    psi(7) = (9/2)*xi(3)*xi(2)*(3*xi(3)-1);        % 边23上第二个节点
    
    psi(8) = (9/2)*xi(3)*xi(1)*(3*xi(3)-1);        % 边31上第一个节点
    psi(9) = (9/2)*xi(1)*xi(3)*(3*xi(1)-1);        % 边31上第二个节点

    % 内部节点的形函数
    psi(10) = 27*xi(1)*xi(2)*xi(3);                % 内部节点

   % 计算形函数关于s的导数
    % 顶点节点
    dpsids(1) = 0.5*((3*xi(1)-1)*(3*xi(1)-2)+3*xi(1)*(3*xi(1)-2)+3*xi(1)*(3*xi(1)-1) )*dxids(1);
    dpsids(2) = 0.5*((3*xi(2)-1)*(3*xi(2)-2)+3*xi(2)*(3*xi(2)-2)+3*xi(2)*(3*xi(2)-1) )*dxids(2);
    dpsids(3) = 0.5*((3*xi(3)-1)*(3*xi(3)-2)+3*xi(3)*(3*xi(3)-2)+3*xi(3)*(3*xi(3)-1) )*dxids(3);
    
    % 边12上的节点
    dpsids(4) = (9/2)*(xi(2)*(3*xi(1)-1)*dxids(1) + xi(1)*(3*xi(1)-1)*dxids(2) + 3*xi(1)*xi(2)*dxids(1));
    dpsids(5) = (9/2)*(xi(2)*(3*xi(2)-1)*dxids(1) + xi(1)*(3*xi(2)-1)*dxids(2) + 3*xi(1)*xi(2)*dxids(2));
    
    % 边23上的节点
    dpsids(6) = (9/2)*(xi(3)*(3*xi(2)-1)*dxids(2) + xi(2)*(3*xi(2)-1)*dxids(3) + 3*xi(2)*xi(3)*dxids(2));
    dpsids(7) = (9/2)*(xi(3)*(3*xi(3)-1)*dxids(2) + xi(2)*(3*xi(3)-1)*dxids(3) + 3*xi(2)*xi(3)*dxids(3));
    
    % 边31上的节点
    dpsids(8) = (9/2)*(xi(1)*(3*xi(3)-1)*dxids(3) + xi(3)*(3*xi(3)-1)*dxids(1) + 3*xi(1)*xi(3)*dxids(3));
    dpsids(9) = (9/2)*(xi(1)*(3*xi(1)-1)*dxids(3) + xi(3)*(3*xi(1)-1)*dxids(1) + 3*xi(1)*xi(3)*dxids(1));
    
    % 内部节点
    dpsids(10) = 27*(xi(2)*xi(3)*dxids(1) + xi(1)*xi(3)*dxids(2) + xi(1)*xi(2)*dxids(3));

    % 计算形函数关于t的导数
    % 顶点节点
    dpsidt(1) = 0.5*((3*xi(1)-1)*(3*xi(1)-2)+3*xi(1)*(3*xi(1)-2)+3*xi(1)*(3*xi(1)-1) )*dxidt(1);
    dpsidt(2) = 0.5*((3*xi(2)-1)*(3*xi(2)-2)+3*xi(2)*(3*xi(2)-2)+3*xi(2)*(3*xi(2)-1) )*dxidt(2);
    dpsidt(3) = 0.5*((3*xi(3)-1)*(3*xi(3)-2)+3*xi(3)*(3*xi(3)-2)+3*xi(3)*(3*xi(3)-1) )*dxidt(3);
    
    % 边12上的节点
    dpsidt(4) = (9/2)*(xi(2)*(3*xi(1)-1)*dxidt(1) + xi(1)*(3*xi(1)-1)*dxidt(2) + 3*xi(1)*xi(2)*dxidt(1));
    dpsidt(5) = (9/2)*(xi(2)*(3*xi(2)-1)*dxidt(1) + xi(1)*(3*xi(2)-1)*dxidt(2) + 3*xi(1)*xi(2)*dxidt(2));
    
    % 边23上的节点
    dpsidt(6) = (9/2)*(xi(3)*(3*xi(2)-1)*dxidt(2) + xi(2)*(3*xi(2)-1)*dxidt(3) + 3*xi(2)*xi(3)*dxidt(2));
    dpsidt(7) = (9/2)*(xi(3)*(3*xi(3)-1)*dxidt(2) + xi(2)*(3*xi(3)-1)*dxidt(3) + 3*xi(2)*xi(3)*dxidt(3));
    
    % 边31上的节点
    dpsidt(8) = (9/2)*(xi(1)*(3*xi(3)-1)*dxidt(3) + xi(3)*(3*xi(3)-1)*dxidt(1) + 3*xi(1)*xi(3)*dxidt(3));
    dpsidt(9) = (9/2)*(xi(1)*(3*xi(1)-1)*dxidt(3) + xi(3)*(3*xi(1)-1)*dxidt(1) + 3*xi(1)*xi(3)*dxidt(1));
    
    % 内部节点
    dpsidt(10) = 27*(xi(2)*xi(3)*dxidt(1) + xi(1)*xi(3)*dxidt(2) + xi(1)*xi(2)*dxidt(3));

end