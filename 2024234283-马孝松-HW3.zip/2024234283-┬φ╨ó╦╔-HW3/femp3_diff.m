function [a,q,f,ae,qe] = femp3_diff(xy,evt,p3xy,p3evt)
%FEMP2_DIFF  set up quadratic anisotropic diffusion matrices
%   [A,Q,f,Ae,Qe] = femp2_diff(xy,evt,p2xy,p2evt);
%   input
%          xy         vertex coordinate vector  
%          evt        element mapping matrix
%          p2xy       P2 node coordinate  vector
%          p2evt      P2 element mapping matrix
%   output
%          A          diffusion matrix
%          Q          mass matrix 
%          f          rhs vector
%          Ae         element diffusion matrices
%          Qe         element mass matrices
%
%   Natural boundary conditions apply. Dirichlet conditions
%   must be explicitly enforced by calling function nonzerobc.
%    TIFISS function: DJS; 3 March 2017.
% Copyright (c) 2011 D.J. Silvester, Qifeng Liao
x=xy(:,1); y=xy(:,2);
nvtx=length(x);
nvtxp3=length(p3xy(:,1));
nel=length(evt(:,1));
fprintf('setting up P2 diffusion matrices...  ')
%
% initialise global matrices
  a = sparse(nvtxp3,nvtxp3);
  q = sparse(nvtxp3,nvtxp3);
  f = zeros(nvtxp3,1);
%
% inner loop over elements  
%对于每个元素的三个顶点，提取它们的 x 和 y 坐标，并存储在矩阵 xl_v 和 yl_v 中。
    for ivtx = 1:3
    xl_v(:,ivtx) = x(evt(:,ivtx));
    yl_v(:,ivtx) = y(evt(:,ivtx)); 
    end
    %这行代码初始化了一个三维数组 ae，用于存储每个元素的扩散矩阵。ae 的大小为 nel x 6 x 6，其中 nel 是元素的数量。
    % 每个元素有 6 个节点（对于 P2 元素，每个三角形有三个顶点和三个边中点），因此每个元素的扩散矩阵是一个 6x6 的矩阵。
    ae = zeros(nel,10,10);
    qe = zeros(nel,10,10);
    fe = zeros(nel,10);  

%------------------------------------------------
% 7 point Gauss rule integration
%设置高斯积分点的数量为 7，并调用 triangular_gausspoints 函数获取高斯点的坐标 s，t 以及对应的权重 wt。
nngpt=19;
[s,t,wt]=triangular_gausspoints(nngpt);
            
for igpt=1:nngpt
       sigpt=s(igpt);
       tigpt=t(igpt);
       wtigpt=wt(igpt);
%  evaluate derivatives etc
         [jac,invjac,phi,dphidx,dphidy] = tderiv(sigpt,tigpt,xl_v,yl_v);
         
         [psi,dpsidx,dpsidy] = tq3deriv(sigpt,tigpt,xl_v,yl_v);
         rhs = tgauss_source(sigpt,tigpt,xl_v,yl_v);
         [diffx,diffy] = tgauss_adiff(sigpt,tigpt,xl_v,yl_v);   
   %组装元素级别的扩散矩阵 ae 和右手边向量 fe。
         for j = 1:10
               for i = 1:10
               ae(:,i,j) = ae(:,i,j) + wtigpt* diffx(:).*dpsidx(:,i).*dpsidx(:,j) .* invjac(:);
               ae(:,i,j) = ae(:,i,j) + wtigpt* diffy(:).*dpsidy(:,i).*dpsidy(:,j) .* invjac(:);
               end
               fe(:,j) = fe(:,j) + wtigpt* rhs(:) .* psi(:,j) .* jac(:); %check factor
         end

         for j = 1:10
               for i = 1:10
               qe(:,i,j) = qe(:,i,j)  + wtigpt*psi(:,i).*psi(:,j) .* jac(:);
               end
 	        end
% end of Gauss point loop
end
%
% perform assembly of global matrix  and source vector
      for krow=1:10
	     nrow=p3evt(:,krow);	 
          for kcol=1:10
		  ncol=p3evt(:,kcol);	  
          a = a + sparse(nrow,ncol,ae(:,krow,kcol),nvtxp3,nvtxp3);
          q = q + sparse(nrow,ncol,qe(:,krow,kcol),nvtxp3,nvtxp3);
          end
          for els=1:nel; f(nrow(els),1)=f(nrow(els),1) + fe(els,krow); end
      end
%
fprintf('done\n')
return

