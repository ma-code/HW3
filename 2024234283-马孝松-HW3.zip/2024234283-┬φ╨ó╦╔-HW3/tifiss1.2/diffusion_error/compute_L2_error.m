function [L2_norm, L2_error, U_exact] = compute_L2_error(x_gal, xy, bound, domain_bounds)
%COMPUTE_L2_ERROR 计算有限元解的L2误差
%   [L2_norm, L2_error, U_exact] = compute_L2_error(x_gal, xy, bound, domain_bounds)
%
% 输入参数:
%   x_gal          - 数值解向量
%   xy             - 节点坐标矩阵 [x,y]
%   bound          - 边界信息
%   domain_bounds  - 计算域边界 [xmin,xmax,ymin,ymax]
%
% 输出参数:
%   L2_norm        - L2范数
%   L2_error       - 每个节点的误差
%   U_exact        - 精确解在节点处的值
%
% 示例:
%   domain_bounds = [min(xy(:,1)), max(xy(:,1)), min(xy(:,2)), max(xy(:,2))];
%   [L2_norm, L2_error, U_exact] = compute_L2_error(x_gal, xy, bound, domain_bounds);

    % 提取域的边界
    xmin = domain_bounds(1);
    xmax = domain_bounds(2);
    ymin = domain_bounds(3);
    ymax = domain_bounds(4);

    % 计算网格参数
    nel = length(x_gal);        % 节点总数
    m = length(bound) / 4;      % 假设边界分为4段
    dx = (xmax - xmin) / m;     % x方向步长
    dy = (ymax - ymin) / m;     % y方向步长

    % 计算精确解（这里使用示例解，可以根据实际问题修改）
    U_exact = compute_exact_solution(xy);

    % 计算误差
    L2_error = (U_exact + x_gal).^2;    % 误差的平方
    L2_norm = sqrt(sum(L2_error) * dx * dy); % L2范数

    % 输出结果
    fprintf('\nL2 Error Analysis:\n');
    fprintf('Number of nodes: %d\n', nel);
    fprintf('L2 norm: %10.4e\n\n', L2_norm);
end
function U_exact = compute_exact_solution(xy)
%计算精确解   
  U_exact = sin(4 * pi * xy(:,1)) .* sin(4 * pi * xy(:,2));
    
end