%TIFISS   returns TIFISS version number
%tifiss scriptfile: DJS; 3 March 2017
%Copyright (c) 2016  D.J. Silvester, Qifeng Liao (see readme.m)
%
%For help, type 'helpme'.
fprintf('This is T-IFISS version 1.2 updated 20 April 2020\n')
fprintf('For help, type "helpme".\n') 
