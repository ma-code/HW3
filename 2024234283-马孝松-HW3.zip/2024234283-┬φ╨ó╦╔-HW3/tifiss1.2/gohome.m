%GOHOME   positions command prompt at top level directory
%   TIFISS scriptfile: DJS; 3 March 2017
%Copyright (c) 2016 by  D.J. Silvester, Qifeng Liao
cd('D:\App\Matlab\Doc\tifiss1.2');
