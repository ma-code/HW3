function [p3xy, p3evt, p3bound] = p3grid(xy, evt, bound, eboundt, iplot)
%P3GRID   cubic element grid generator
%   Node numbering scheme for P3 element:
%
%           3
%           /\
%          /  \
%         8    7
%        /      \
%       9   10   6
%      /          \
%     1-----4,5----2
%
% 节点编号说明：
% 1,2,3: 顶点
% 4,5: 边12上的点（1/3和2/3处）
% 6,7: 边23上的点（1/3和2/3处）
% 8,9: 边31上的点（2/3和1/3处，注意顺序）
% 10: 重心点

if nargin<5, iplot=1; end

nel = length(evt(:,1));

% 寻找所有三角形的边
tedge = [];
for i = 1:nel
   tedge = [tedge; evt(i,1),evt(i,2); evt(i,2),evt(i,3); evt(i,3),evt(i,1)];
end

% 移除重复边
ne = length(tedge(:,1));
for i = 1:ne
    t = find((tedge(i,1)==tedge(1:(i-1),1)|(tedge(i,1)==tedge(1:(i-1),2)))&...
             ((tedge(i,2)==tedge(1:(i-1),1))|(tedge(i,2)==tedge(1:(i-1),2))));
    if length(t)>0
       tedge(i,1) = nan;
    end
end

t = find(tedge(:,1)>0);
tedge = tedge(t,:);
ne = length(tedge);

% 为每个三角形找到对应的边
eve = zeros(nel,3);
for i = 1:nel
    % 边的顺序：12, 23, 31
    eve(i,1) = find((evt(i,1)==tedge(:,1)|evt(i,1)==tedge(:,2))&(evt(i,2)==tedge(:,1)|evt(i,2)==tedge(:,2))); % 边12
    eve(i,2) = find((evt(i,2)==tedge(:,1)|evt(i,2)==tedge(:,2))&(evt(i,3)==tedge(:,1)|evt(i,3)==tedge(:,2))); % 边23
    eve(i,3) = find((evt(i,3)==tedge(:,1)|evt(i,3)==tedge(:,2))&(evt(i,1)==tedge(:,1)|evt(i,1)==tedge(:,2))); % 边31
end

% 存储原始节点数量
n_node = length(xy(:,1));

% 计算边上的点的坐标
edge_points_xy = zeros(2*ne,2);
for i = 1:ne
    v1 = tedge(i,1);
    v2 = tedge(i,2);    
    edge_points_xy(2*i-1,:) = xy(v1,:) + (xy(v2,:) - xy(v1,:))/3;  % 1/3点
    edge_points_xy(2*i,:) = xy(v1,:) + 2*(xy(v2,:) - xy(v1,:))/3;  % 2/3点
end
% 计算重心点
centroid_xy = zeros(nel,2);
for i = 1:nel
    centroid_xy(i,:) = (xy(evt(i,1),:) + xy(evt(i,2),:) + xy(evt(i,3),:))/3;
end

% 组合所有节点坐标
p3xy = [xy; edge_points_xy; centroid_xy];

% 创建P3单元节点映射矩阵
p3evt = zeros(nel,10);
for i = 1:nel
    % 顶点 (1,2,3)
    p3evt(i,1:3) = evt(i,1:3);
   
    % 边12上的点 (4,5)
    edge_idx = eve(i,1);
    p3evt(i,4) = n_node + 2*edge_idx-1;  % 1/3点
    p3evt(i,5) = n_node + 2*edge_idx;    % 2/3点   
    % 边23上的点 (6,7)
    edge_idx = eve(i,2);
    p3evt(i,6) = n_node + 2*edge_idx-1;  % 1/3点
    p3evt(i,7) = n_node + 2*edge_idx;    % 2/3点   
    % 边31上的点 (8,9)
    edge_idx = eve(i,3);
    p3evt(i,8) = n_node + 2*edge_idx;    % 2/3点
    p3evt(i,9) = n_node + 2*edge_idx-1;      % 1/3点   
    % 重心点 (10)
    p3evt(i,10) = n_node + 2*ne + i;
end
%%判断点，并调换位置
for i=1:nel
%点6点7和点3的距离, 点7应该靠近点3
L6=(p3xy(p3evt(i,6),1)-p3xy(p3evt(i,3),1))^2+(p3xy(p3evt(i,6),2)-p3xy(p3evt(i,3),2))^2;
L7=(p3xy(p3evt(i,7),1)-p3xy(p3evt(i,3),1))^2+(p3xy(p3evt(i,7),2)-p3xy(p3evt(i,3),2))^2;
%点8点9和点1的距离，点9应该靠近点1
L8=(p3xy(p3evt(i,8),1)-p3xy(p3evt(i,1),1))^2+(p3xy(p3evt(i,8),2)-p3xy(p3evt(i,1),2))^2;
L9=(p3xy(p3evt(i,9),1)-p3xy(p3evt(i,1),1))^2+(p3xy(p3evt(i,9),2)-p3xy(p3evt(i,1),2))^2;
%点4点5和点2的距离 点5应该靠近点2
L4=(p3xy(p3evt(i,4),1)-p3xy(p3evt(i,2),1))^2+(p3xy(p3evt(i,4),2)-p3xy(p3evt(i,2),2))^2;
L5=(p3xy(p3evt(i,5),1)-p3xy(p3evt(i,2),1))^2+(p3xy(p3evt(i,5),2)-p3xy(p3evt(i,2),2))^2;
if L6 < L7
    tihuan=p3evt(i,6);
    p3evt(i,6)=p3evt(i,7);
    p3evt(i,7)=tihuan;
end
if L8 < L9
    tihuan=p3evt(i,8);
    p3evt(i,8)=p3evt(i,9);
    p3evt(i,9)=tihuan;
end
if L4 < L5
    tihuan=p3evt(i,4);
    p3evt(i,4)=p3evt(i,5);
    p3evt(i,5)=tihuan;
end
end

% 处理P3边界节点
% eboundt 是一个 n x 2 的矩阵，其中：
% 第一列 eboundt(i,1)：边界单元的编号（el）
% 第二列 eboundt(i,2)：该单元中边的局部编号（edge）
n_eboundt = length(eboundt);
p3bound = bound;  % 先包含顶点边界节点

% 添加边界边上的两个节点
for i = 1:n_eboundt
    el = eboundt(i,1);    % 边界单元编号
    edge = eboundt(i,2);  % 边的编号
    
    % 对于P3元素，每条边上有两个节点
    if edge == 3      % 边12
        p3bound = [p3bound; p3evt(el,4); p3evt(el,5)];
    elseif edge == 1  % 边23
        p3bound = [p3bound; p3evt(el,6); p3evt(el,7)];
    else             % 边31
        p3bound = [p3bound; p3evt(el,8); p3evt(el,9)];
    end
end

% 移除重复节点
nbound = length(p3bound);
for i = 1:nbound-1
    for j = i+1:nbound
        if p3bound(j) == p3bound(i)
            p3bound(j) = nan;
        end
    end
end

% 只保留非nan的节点
t = find(p3bound > 0);
p3bound = p3bound(t);

% 移除重复节点（保持顺序）
[~,idx] = unique(p3bound,'first');
idx = sort(idx);  % 保持原始顺序
p3bound = p3bound(idx);

% 绘制网格

if (iplot)
% close the P1 grid figure
if ishandle(10), close 10, end
% plot the generated P2 grid
    nvtx=length(xy(:,1));
    adj=sparse(nvtx,nvtx);
    for i=1:nel
	adj(p3evt(i,1),p3evt(i,2)) =1;
  	adj(p3evt(i,2),p3evt(i,3)) =1;
	adj(p3evt(i,3),p3evt(i,1)) =1;
    end
    figure(11)
    gplot(adj,p3xy,'b')
    axis('equal')
    hold on
    plot(p3xy(:,1),p3xy(:,2),'ro')
    axis('off')
    xybd=p3xy(p3bound,:);
    plot(xybd(:,1),xybd(:,2),'ko')
    hold off
    title('P3 finite element subdivision');
    drawnow
end
end