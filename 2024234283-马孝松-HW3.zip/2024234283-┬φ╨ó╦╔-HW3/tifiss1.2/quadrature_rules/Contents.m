% QUADRATURE_RULES
%
% Files
%   assemble_gausspoints   - generates Gauss points from triangular coordinates
%   gausspoints_oned       - constructs one-dimensional Gauss point rule
%   triangular_gausspoints - Gauss point rules for triangular elements
