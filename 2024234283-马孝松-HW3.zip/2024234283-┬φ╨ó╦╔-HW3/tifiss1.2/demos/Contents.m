% DEMOS
%
% Files
%   diffproblemdemo    - diffusion test problems
%   selfadaptdemo      - adaptive refinement
