2     % reference problem
5     % grid parameter
1     % uniform grid
1     % refinement level
1     % P1/P2
1     % linear bubble functions

%% Data file for square anisotropic diffusion problem
