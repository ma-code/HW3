5     % reference problem
1     % structured mesh
5     % mesh level
1     % stretch factor
0     % refinement level
2     % P1/P2 switch

%% Data file for L-shape diffusion problem
